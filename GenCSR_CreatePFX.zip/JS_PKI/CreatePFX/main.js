import * as pkijs from './pkijs.es.js';
import * as pvutils from './pkilibs/pvutils.js';
import * as peculiarCrypto from './node_modules/@peculiar/webcrypto/build/webcrypto.js';
import * as fs from 'fs';

//since we are in node
const webcrypto = new peculiarCrypto.Crypto();
const name = "newEngine";
pkijs.setEngine(name, new pkijs.CryptoEngine({ name, crypto: webcrypto }));


//in live, the below vars are coming from KEYUTIL generate KEYPAIR and from Sectigo
const myprkey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCEAp4eIWd92CYd0NEvqaLvdr6EE5pdep5Vx5TK506iZF1EnPGj0foLsy+1XaZfnBbD10LUkEC2ApWxaJ1lntz0WcawMLEEhVZtyUCKlA0nK3CUn0Ymw+TCVLR64wPG+sLt4KOuBUseMDXtIWo9OXosoGGleDoKTy0ho7mzPDQnBOBpWj7Ejitz1lB2Hfs0RxrptQerFp5XhTH9vBnnBqr+n1M1KFuU/Y15UDNLzSW3IYBxoMToIvRi9McQgnCx21+AYxu3zG2USQ4CJpf1Q/Bal7SmGYojz1KVrlXtHUh0x77eGawj816xQSoPLTnQlONYcMiwliUzdX6L/r4RvZkJAgMBAAECggEALircMZ1tHE3jxrmo7wpcuXLF3lscuWSQy18pYmzSy2heVgitWaWt1Tmtjbha30UvkP5PmRd6Ci2NPKZhpZCRpcNgAW6F+hbHy01/DPgKQZCnptKtLhGEh5IoLHIIeCZq1daiZ9HiG4Sw12XASfk4CTNt8vjBE6ntFr6zy0Na2eoMrFwteTFKpPiBiz6MVlXF8DfiMPz9MROn/7Vzh7yoOnZ5mPbLDeISJShSr1FtaaAVO5cHc431Nvt7GnLm+t3+xHy0TrJWMGtcMAjMGQBJjv33m2Z01xmp0TAlBc0md78zFKwhOzSQ6MZYmzF8/0iPHIXd/zr9kncpt8lBfy54AQKBgQD1oFu4KxZGkKE11F6c0rLl1drfAdlmHSiD9UBgzJEp1WoVOjTD4o1p+8NkdBf87yJVURd/Bg9B/S8t/zBL8m9DkOg60WSyxdsbNS0nEJ2ucsYlNHYwwhtBA2j4Z4FaJDI+QNA6Qe6zjBUzG8Zn/zatL3SW+RwO+lwtIF67g0owYQKBgQCJld/EdkbLtYMgfMD7UnRZd5iLvshdVOQKHqvwLU+Hg9Pj0/0bzL2E5Sxlf3gT1pbnn6PG+J+HGEs/pavW2xEJ8pGQzPRRmwiRuVmhH9ekSurz3OKFGmpXU0EYpxe6b0IxUFyXD8rPc+azHRtQJ/rHNvVJKPIgFJbnR34hYPhJqQKBgBLF89yqpmQ0T63+klCoJfY9FyJuUMBmQB990jLTz9CDuDzxGvFR0n8kN/XojaDOYjBlJ0eVHftsL3vzgix71hcy7xz3vhuP1cRJly7iLTsVGKHlVZc6brzUVuSNfKx4EcMCTyf0vBrK/R/P4qU2M2afNukHFybp6bulOrhYO4ZhAoGAd2tzEl9nC6G88xHVn07uVkmMSp+J4hiw5mfA7XMmuIUgAXwbEWoghZ01b9O4Md/sk5bo3Ocn8GaRyejOwmra2zuERZ7f4YUjZvjuZv/weFXeoVRz+Pv4mVtWAUPnQJcZaRxLgYLfkjkTYRw+fNB2xztYo+u6XUYBxTU0sVwtpiECgYEAzGgo/8SE75V9Ckx/oT/fugtaVQek2rmjeYNALKA8hKMzE9cLu/cUwS/zzAN+h/FsipApH5na3wxFs0O3fI6HHKbtAwHK7urYq8mE+SjYBztkjDEVxQ0v0kiHZ5Xw0QGeUFRsSC1VF3zplFwPI2pmcl+r1oylOnCfIdnnxGQeE0Y=";
const mycert = "MIIEhjCCA26gAwIBAgITdgAAAEYDu2a61fU9QwAAAAAARjANBgkqhkiG9w0BAQsFADBDMRMwEQYKCZImiZPyLGQBGRYDcGtpMRcwFQYKCZImiZPyLGQBGRYHbGFiMjAxNjETMBEGA1UEAxMKUEtJLUxhYiBDQTAeFw0yMjA4MTAyMjQ2MTJaFw0yNDA1MTUyMTE5MTZaMDQxCzAJBgNVBAYTAlVTMQ0wCwYDVQQKEwRUZXN0MRYwFAYDVQQDEw1leGFtcGxlY24uY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhAKeHiFnfdgmHdDRL6mi73a+hBOaXXqeVceUyudOomRdRJzxo9H6C7MvtV2mX5wWw9dC1JBAtgKVsWidZZ7c9FnGsDCxBIVWbclAipQNJytwlJ9GJsPkwlS0euMDxvrC7eCjrgVLHjA17SFqPTl6LKBhpXg6Ck8tIaO5szw0JwTgaVo+xI4rc9ZQdh37NEca6bUHqxaeV4Ux/bwZ5waq/p9TNShblP2NeVAzS80ltyGAcaDE6CL0YvTHEIJwsdtfgGMbt8xtlEkOAiaX9UPwWpe0phmKI89Sla5V7R1IdMe+3hmsI/NesUEqDy050JTjWHDIsJYlM3V+i/6+Eb2ZCQIDAQABo4IBgDCCAXwwFgYDVR0RBA8wDYILZXhhbXBsZS5jb20wHQYDVR0OBBYEFA9o9TYO5tMOjOn8pTRhG4qvnF+4MB8GA1UdIwQYMBaAFIwWZlymwBKNKrH9uIef1fdcy6iTMDYGA1UdHwQvMC0wK6ApoCeGJWh0dHA6Ly9jcmwubGFiMjAxNi5wa2kvcGtpLWxhYi1jYS5jcmwwawYIKwYBBQUHAQEEXzBdMDEGCCsGAQUFBzAChiVodHRwOi8vYWlhLmxhYjIwMTYucGtpL3BraS1sYWItY2EuY3J0MCgGCCsGAQUFBzABhhxodHRwOi8vb2NzcC5sYWIyMDE2LnBraS9vY3NwMA4GA1UdDwEB/wQEAwIFoDA7BgkrBgEEAYI3FQcELjAsBiQrBgEEAYI3FQiDzs45gq2CR4bFmyWH4d4F9pxpLevAJIW50XMCAWQCAQkwEwYDVR0lBAwwCgYIKwYBBQUHAwEwGwYJKwYBBAGCNxUKBA4wDDAKBggrBgEFBQcDATANBgkqhkiG9w0BAQsFAAOCAQEAH9BbP0xv0U+P2R+lKQY+V9hIC46Ef7kzcBhnOAn0jMzhBzZX4aUd/EBSU+5nT1R0gyXaGQGpQNt5k/eWD5ihSaIxEGL7bF37NleR2ZhgrYQHRFxsyrdJFUxonIMyipMspfS9tFFiXxytRb7LXLdCvkS9wx0MudbSxF9tW9ttsxJ0bQI7QGR8nJ1BzRVXUlqL9T+wQfMxo/qqZ3gkfZI7/g54qgTTZd5bbZ6mnEBcPcU2dMLNI15Tic5v5emxjS1jR+cAalidjwIAUyI18UbQmQ9hfJOW0SqpvpEy6+h5ovntIV/N5Sj4lNLWZKh2MCHAl2L8BDrKSEjXFZvd974xfg==";
const ica = "MIIEUjCCAzqgAwIBAgITWAAAABAO7nKfcNrzUQAAAAAAEDANBgkqhkiG9w0BAQsFADBFMRMwEQYKCZImiZPyLGQBGRYDcGtpMRcwFQYKCZImiZPyLGQBGRYHbGFiMjAxNjEVMBMGA1UEAxMMUEtJLUxhYi1Sb290MB4XDTIyMDUxNTIxMDkxNloXDTI0MDUxNTIxMTkxNlowQzETMBEGCgmSJomT8ixkARkWA3BraTEXMBUGCgmSJomT8ixkARkWB2xhYjIwMTYxEzARBgNVBAMTClBLSS1MYWIgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCy7J0p41PNSzNXXM72spJy6fksfNxYoj8qqfdIl3Amw2/kKBXfIcz+aPI6TxhPQuFqxYuEImVuynXOju8LT5UZdoiaf6VysjxHJMQql1WURwBDbUl+My0YEpWksRa3upA+MroKJiDgUfqkFs5nD2LNJkFLQkkGNODYjaPP5Ompo9SCu8oJFo2kvA3zB5U3iqz50Jct2yjo3E2jchOcQPV+Dhpqy6KpF0BLVnk2J6BITQIEFiVq0+j7sz4i6kigq1IcivE6WTj0PTtNrL1FCuST3vFY6evKjPAeesJKUVJt9hgzOzlmw2D69H698BwaBR0LR5qPmiZgolCwEO9gmpjLAgMBAAGjggE7MIIBNzAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQUjBZmXKbAEo0qsf24h5/V91zLqJMwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwDgYDVR0PAQH/BAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAUwW4VsGooXpMzmj0IkgzcF7hjCY0wOAYDVR0fBDEwLzAtoCugKYYnaHR0cDovL2NybC5sYWIyMDE2LnBraS9wa2ktbGFiLXJvb3QuY3JsMG0GCCsGAQUFBwEBBGEwXzAzBggrBgEFBQcwAoYnaHR0cDovL2FpYS5sYWIyMDE2LnBraS9wa2ktbGFiLXJvb3QuY3J0MCgGCCsGAQUFBzABhhxodHRwOi8vb2NzcC5sYWIyMDE2LnBraS9vY3NwMA0GCSqGSIb3DQEBCwUAA4IBAQCkhbfpxOAaxk0ToTe3BkUFVaOa1PJSE2gK1nbMBLDTfzMq3QumCUwJRXs9x8YTifgEAra7etrM45jMC4egqiRB5OAid00CBePzhc8Zf7fh+Dat82YL9lSIY2J+j+IosoflZZ5pL3HmNxwz3rCse8wi0r1+1TQ+Jme6HhlgCtNJTpUDWHpkXQmgubr3eu4VIw8iJoWtb5GtWUrEnSSfGDQGQ3VKuZ/d11HrjDUa8hXoZ8JJ8T1nncIKL5oAXDzz2ok7fQG+OHIOcLPF2HS2e+HeFWly7Oln5ON9C1p1AtH/B4yE4M47pgDxdWo2ZEbvo3P+phrCjQVa4RJ2FfR9wVFM";
const root = "MIIDZTCCAk2gAwIBAgIQM6RVcIAOpZ5E1nRf4Rek8TANBgkqhkiG9w0BAQsFADBFMRMwEQYKCZImiZPyLGQBGRYDcGtpMRcwFQYKCZImiZPyLGQBGRYHbGFiMjAxNjEVMBMGA1UEAxMMUEtJLUxhYi1Sb290MB4XDTIyMDMxMDEyMDIyMVoXDTMyMDMxMDEyMTIyMVowRTETMBEGCgmSJomT8ixkARkWA3BraTEXMBUGCgmSJomT8ixkARkWB2xhYjIwMTYxFTATBgNVBAMTDFBLSS1MYWItUm9vdDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAO7+CAx7lbXcYshcyOqYrxIGTtqvqS3n8/DSw3yKzMttq9ADGHJEl5PFk99mMUr+h1QJ5hj1flIScoH+gQpnRY74z/zaGDRECzhLV1toFMFQ0jAqsMkdDmzY6Vux0EWjcRLe+MAyPXLNl3JTOQxiMQj+5Jlnt2BMCexKDgQ33RYdfbS/Sc7fXIBAFg9EH2o4sGS9bQH+7UXKBqK9685LQoLhjr6V7vvgGuhll8TT+TXn7vaQUyL/Hty9YKCj/LRYO7rzlP14iJYavmNzNMpHKyH1YrWxZG/WuJVMYPI3nzgvzVzqS+ayKIyQjevekXflvwUn/ARHgYvlYW2DXVJXNu0CAwEAAaNRME8wCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMFuFbBqKF6TM5o9CJIM3Be4YwmNMBAGCSsGAQQBgjcVAQQDAgEAMA0GCSqGSIb3DQEBCwUAA4IBAQARRRaRqzioXurGr39zw7MNwMOIP/5dVAAApl4jFYJ4Ro4vZh+VdeCyuXrWe3Q1Yv05FiK5HCSoWYqEyATyekRVKXCJprCbb8GQwdrl+j+FYx69l3KYMkZP2BfwtZMFsmeP7hzC1aPARXfT2SVM2rpDGjGuD68h8IkCiCWB/REgvBNGgECkkVnKh1FgcsJQ7FW4UbSd0TAx9f8O6VpYuu+3hXQP0g8SaEalnwCW9TT+JJiPjkmIKh9JRhjhE5CMAtBIFQPKicvTtF1JVjbktO142tnXAomvnDqoHlJ69cN1V2+rwYAwIVVT/pCM8VTYkZVd+wenuolta+hzrwrH/p9D";
//in case the privatekey was generated using KUTIL, we need to trim the header/footer and remove the line breaks.
//var prTrim = prPem.replace("-----BEGIN PRIVATE KEY-----","").replace("-----END PRIVATE KEY-----","").replace(/(\r\n|\r|\n)/g,"");

async function createPFX(password, hash = "SHA-256") {
    //#region Create simplified structires for certificate and private key
    const certRaw = pvutils.stringToArrayBuffer(pvutils.fromBase64(mycert));
    const certSimpl = pkijs.Certificate.fromBER(certRaw);    
    const icaRaw = pvutils.stringToArrayBuffer(pvutils.fromBase64(ica));
    const icaSimpl = pkijs.Certificate.fromBER(icaRaw);
    const rootRaw = pvutils.stringToArrayBuffer(pvutils.fromBase64(root));
    const rootSimpl = pkijs.Certificate.fromBER(rootRaw);    
    const pkcs8Raw = pvutils.stringToArrayBuffer(pvutils.fromBase64(myprkey));
    const pkcs8Simpl = pkijs.PrivateKeyInfo.fromBER(pkcs8Raw);
    //#endregion
    //#region Put initial values for PKCS#12 structures
    const pkcs12 = new pkijs.PFX({
        parsedValue: {
            integrityMode: 0,
            authenticatedSafe: new pkijs.AuthenticatedSafe({
                parsedValue: {
                    safeContents: [
                        {
                            privacyMode: 0,
                            value: new pkijs.SafeContents({
                                safeBags: [
                                    new pkijs.SafeBag({
                                        bagId: "1.2.840.113549.1.12.10.1.1",
                                        bagValue: pkcs8Simpl
                                    }),
                                    new pkijs.SafeBag({
                                        bagId: "1.2.840.113549.1.12.10.1.3",
                                        bagValue: new pkijs.CertBag({
                                            parsedValue: certSimpl
                                        })
                                    }),
                                    new pkijs.SafeBag({
                                        bagId: "1.2.840.113549.1.12.10.1.3",
                                        bagValue: new pkijs.CertBag({
                                            parsedValue: icaSimpl
                                        })
                                    }),
                                    new pkijs.SafeBag({
                                        bagId: "1.2.840.113549.1.12.10.1.3",
                                        bagValue: new pkijs.CertBag({
                                            parsedValue: rootSimpl
                                        })
                                    })
                                ]
                            })
                        }
                    ]
                }
            })
        }
    });    
    //#region Encode internal values for all "SafeContents" firts (create all "Privacy Protection" envelopes)
    if (!(pkcs12.parsedValue && pkcs12.parsedValue.authenticatedSafe)) {
        throw new Error("pkcs12.parsedValue.authenticatedSafe is empty");
    }    
    //await pkcs12.parsedValue.authenticatedSafe.makeInternalValues({
        //safeContents: [
            //{
            // Empty parameters since we have "No Privacy" protection level for SafeContents
            //}
        //]
    //});
    //#endregion
    //#region Encode internal values for "Integrity Protection" envelope
    await pkcs12.makeInternalValues({
        password: pvutils.stringToArrayBuffer(password),
        iterations: 100000,
        pbkdf2HashAlgorithm: hash,
        hmacHashAlgorithm: hash
    });
    //#endregion
    //#region Encode output buffer
    return pkcs12.toSchema().toBER();
    //#endregion
}

const pfx = await createPFX("autoGeneratedComplexPassword");
console.log(pfx);

var buf = Buffer.from(pfx, 'binary');

fs.writeFile('myFullpfx.pfx', buf, function(err) {
    if (err) throw err;
});