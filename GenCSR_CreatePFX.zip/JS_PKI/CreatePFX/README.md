all dependency libraries are saved locally in /pkilibs

since we are in node.js, we need to install webcrypto

    npm install @peculiar/webcrypto

we also need 'fs' for filesystem

    npm install fs

you can refer to https://pkijs.org/examples/PKCS12SimpleExample/PKCS12SimpleExample.html for full demo of PKCS12/PFX

the file org.js is the main script for the above link (which implements createPFX functionality)

-----------------------------

support documents/links:

pkijs:
https://pkijs.org/examples/PKCS12SimpleExample/PKCS12SimpleExample.html

https://pkijs.org/docs/index.html

https://github.com/SSLMate/go-pkcs12/issues/11
