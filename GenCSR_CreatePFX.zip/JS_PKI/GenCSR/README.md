when running node.exe main.js, it should write a CSR in PEM format to the console

we need jsrsasign jsrsasign-util libraries

npm install jsrsasign jsrsasign-util

-----------------------------

support documents/links:

https://javascript.hotexamples.com/examples/jsrsasign/KEYUTIL/generateKeypair/javascript-keyutil-generatekeypair-method-examples.html

https://kjur.github.io/jsrsasign/api/symbols/KJUR.asn1.csr.CSRUtil.html

https://kjur.github.io/jsrsasign/api/symbols/KJUR.asn1.csr.CertificationRequest.html

https://www.npmjs.com/package/jsrsasign

https://github.com/kjur/jsrsasign

https://kjur.github.io/jsrsasign/tool/tool_csr.html

https://kjur.github.io/jsrsasign/api/symbols/KJUR.asn1.csr.CSRUtil.html

