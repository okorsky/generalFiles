import { KJUR, KEYUTIL } from 'jsrsasign';

//generate RSA keypair of size 2048 bits
var rsaKeypair = KEYUTIL.generateKeypair("RSA", 2048);

//console.log(rsaKeypair)

var pubPem = KEYUTIL.getPEM(rsaKeypair.pubKeyObj); //get public key from the generated pair in PEM format
var prPem = KEYUTIL.getPEM(rsaKeypair.prvKeyObj, "PKCS8PRV"); //get private key from the generated pair in PEM format

//console.log(prPem);

//only CN and SAN are vars, the rest are consts
//there has to be at least one SAN matching the CN (browsers never read the CN, they always read the SANs)

var csr = new KJUR.asn1.csr.CertificationRequest({
    subject: {str:"/CN=examplecn.com/C=US/O=Test"},
    sbjpubkey: pubPem,    
    extreq: [{extname:"subjectAltName",array:[{dns:"example.com"}]}],
    sigalg: "SHA256withRSA",
    sbjprvkey: prPem
  });

//output the generated CSR in PEM format to the console
console.log(csr.getPEM());