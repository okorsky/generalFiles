import { KJUR, KEYUTIL } from 'jsrsasign';

var rsaKeypair = KEYUTIL.generateKeypair("RSA", 2048);

//console.log(rsaKeypair)

var pubPem = KEYUTIL.getPEM(rsaKeypair.pubKeyObj);
var prPem = KEYUTIL.getPEM(rsaKeypair.prvKeyObj, "PKCS8PRV");

console.log(prPem);

var csr = new KJUR.asn1.csr.CertificationRequest({
    subject: {str:"/CN=examplecn.com/C=US/O=Test"},
    sbjpubkey: pubPem,    
    extreq: [{extname:"subjectAltName",array:[{dns:"example.com"}]}],
    sigalg: "SHA256withRSA",
    sbjprvkey: prPem
  });

console.log(csr.getPEM());